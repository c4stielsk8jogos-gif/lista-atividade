nome = input("digite o nome do seu heroi: ")
print(f"o heroi {nome} acaba de entrar na guilda")
