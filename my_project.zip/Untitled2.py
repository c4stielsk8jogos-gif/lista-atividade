nome = input("digite o nome do seu heroi: ")
print(nome)
