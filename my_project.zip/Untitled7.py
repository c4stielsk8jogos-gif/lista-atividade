resposta = input("deseja salvar o pogresso? (S/N) ")
print(f"resposta digitada {resposta} ")
