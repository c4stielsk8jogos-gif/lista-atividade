nome = input("digte seu nome: ")
nivel = int(input("digite seu nivel: "))
magia = input("tem magia? (S/N) : ").upper() =="sim"
print (f" nome {nome} | nivel {nivel} | magia{magia} ")
