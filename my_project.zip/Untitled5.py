print("espada, escudo e poçao")
