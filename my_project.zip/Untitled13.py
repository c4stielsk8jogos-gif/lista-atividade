print("Preço de cada poção: 10 moedas ³¹")

quantidade = int(input("Quantas poções você quer? "))
total = quantidade * 10

print(f"Valor total da fatura: {total} moedas ")
