cidade = input("digite o nome de uma cidade: ")
print(f"viajante, voce esta a caminho de {cidade} tome cuidado!")

