x = input(" a coordenada x: ")
y = input("a coordenada y: ")
print(f" o personagem foi movido para a posiçao ({x}, {y} ) ")
