idade = input("Sua idade: ")
idade = int(idade)
print(idade + 1)
