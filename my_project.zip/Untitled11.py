energia = 100
escudo = 50
print(f" status: energia em {energia}% | escudo em {escudo}%" )
