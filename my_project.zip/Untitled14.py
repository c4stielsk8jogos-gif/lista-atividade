# O objetivo é ler o nome e dar boas-vindas
nome = input("Digite seu nome: ")
print(f"Bem-vindo, {nome}! ")
