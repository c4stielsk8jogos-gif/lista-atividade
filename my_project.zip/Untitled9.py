vidas = int(input("digite quantas vidas o jogador tem: "))
print(f"o dobro das vidas e {vidas * 2} ")
